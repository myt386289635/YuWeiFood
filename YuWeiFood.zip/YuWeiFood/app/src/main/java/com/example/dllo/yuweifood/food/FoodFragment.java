package com.example.dllo.yuweifood.food;

import android.view.View;

import com.example.dllo.yuweifood.R;
import com.example.dllo.yuweifood.base.BaseFragment;

/**
 * Created by dllo on 16/8/31.
 */
public class FoodFragment extends BaseFragment {
    private static final String TAG = "FoodFragment --> ***********";

    @Override
    protected int initLayout() {
        return R.layout.food_fragment;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
