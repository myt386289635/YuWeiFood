package com.example.dllo.yuweifood.eventbusbean;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean {

    public Boolean showing;

    public Boolean getShowing() {
        return showing;
    }

    public void setShowing(Boolean showing) {
        this.showing = showing;
    }
}
