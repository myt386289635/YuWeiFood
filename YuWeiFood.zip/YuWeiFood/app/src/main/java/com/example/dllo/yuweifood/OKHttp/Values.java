package com.example.dllo.yuweifood.OKHttp;

/**
 * Created by dllo on 16/9/1.
 */
public class Values {
    private static final String TAG = "Values --> ***********";

    public static final String FoodFragment_str = "http://www.youyuwei.com/api/note?oauth_version=1.0&oauth_nonce=db69b68b-5b6b-4d15-85df-35aae2caccb0&oauth_consumer_key=5&device_type=android&screen_width=1080&list=RefinedList&device_id=08%3A00%3A27%3A4c%3A0a%3A58&ver=6&ywsdk_ver=20140507&sys_ver=4.4.4&ver_code=33&channel_id=yingyongbao&oauth_signature=32d3MpJiAy0hkpZnbhlLxzf7x%2FE%3D&x_auth_mode=client_auth&start=0&device_token=AqSjKQzxiUql-xNhXUhJnYyWggMObybW_emSAtg7Z_xS&oauth_signature_method=HMAC-SHA1&oauth_token=0_9837387abc33331ab&open_udid=08%3A00%3A27%3A4c%3A0a%3A58&app_ver=3.1&app_code=com.yuwei.android&oauth_timestamp=1472637081&screen_height=1776";
    public static final String FoodFragment_attentFragment_str = "http://www.youyuwei.com/api/note?oauth_version=1.0&oauth_nonce=82340ab2-572d-4f7f-985b-a462ef2ea09e&oauth_consumer_key=5&device_type=android&screen_width=1080&list=FollowNoteList&device_id=08%3A00%3A27%3A4c%3A0a%3A58&ver=6&ywsdk_ver=20140507&sys_ver=4.4.4&ver_code=33&channel_id=yingyongbao&oauth_signature=9tjig%2FQjvhwekUl7Vj16QP6FdzE%3D&x_auth_mode=client_auth&start=0&device_token=AqSjKQzxiUql-xNhXUhJnYyWggMObybW_emSAtg7Z_xS&oauth_signature_method=HMAC-SHA1&oauth_token=0_9837387abc33331ab&open_udid=08%3A00%3A27%3A4c%3A0a%3A58&app_ver=3.1&app_code=com.yuwei.android&oauth_timestamp=1472636714&screen_height=1776";

}
