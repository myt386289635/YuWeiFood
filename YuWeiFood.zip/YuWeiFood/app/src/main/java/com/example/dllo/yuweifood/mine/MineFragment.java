package com.example.dllo.yuweifood.mine;

import android.view.View;

import com.example.dllo.yuweifood.R;
import com.example.dllo.yuweifood.base.BaseFragment;

/**
 * Created by dllo on 16/8/31.
 */
public class MineFragment extends BaseFragment{
    private static final String TAG = "MineFragment --> ***********";

    @Override
    protected int initLayout() {
        return R.layout.mine_fragment;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
