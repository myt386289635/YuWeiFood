package com.example.dllo.yuweifood.local;

import android.view.View;

import com.example.dllo.yuweifood.R;
import com.example.dllo.yuweifood.base.BaseFragment;

/**
 * Created by dllo on 16/8/31.
 */
public class LocalFragment extends BaseFragment{
    private static final String TAG = "LocalFragment --> ***********";

    @Override
    protected int initLayout() {
        return R.layout.local_fragment;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
