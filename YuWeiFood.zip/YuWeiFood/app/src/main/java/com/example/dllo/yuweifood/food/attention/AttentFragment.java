package com.example.dllo.yuweifood.food.attention;

import android.view.View;

import com.example.dllo.yuweifood.R;
import com.example.dllo.yuweifood.base.BaseFragment;

/**
 * Created by dllo on 16/8/31.
 */
public class AttentFragment extends BaseFragment{
    private static final String TAG = "AttentFragment --> ***********";

    @Override
    protected int initLayout() {
        return R.layout.food_fragment_attent_fragment;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
